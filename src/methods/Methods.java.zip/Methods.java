package methods;

public class Methods {

    public static void main(String[] args) {

        /*
        All you need to do is come up with method names to practice.
        method that calculates the tax for married couples
        method that calculates tax for singles
        method that changes the color of the screen
        method that adds 2 numbers
        method that divides 2 numbers
        method that finds the digits form text
        method that searches for $ symbols
         */



    }

    public static void calculatesTheTaxForMarriedCouples(){}
    public static void calculatesTheTaxForSingles(){}
    public static void changesTheColorOfTheScreen(){}
    public static void adds2Numbers(){}
    public static void divides2Numbers(){}
    public static void findsTheDigitsFormText(){}
    public static void searchesFor$Symbols(){}





}
